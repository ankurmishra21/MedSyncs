<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/animations.css">  
    <link rel="stylesheet" href="css/main.css">  
    <link rel="stylesheet" href="css/login.css">
        
    <title>Patient Login</title>

</head>
<body>
    <!-- Navigation Bar -->
    <table border="0" style="width: 100%; padding: 0; margin: 0; border-spacing: 0;">
        <tr style="background-color: #fff; box-shadow: 0 2px 5px rgba(0,0,0,0.05);">
            <td width="50%" style="text-align: left; padding: 10px 0;">
                <a href="index.html" class="non-style-link">
                    <font class="medsync-logo" style="color: var(--primarycolor);">MedSync. </font>
                    <font class="medsync-logo-sub" style="color: #888;">| THE ECHANNELING PROJECT</font>
                </a>
            </td>
            <td width="40%" style="text-align: right;">
               <a href="patient-login.php" class="non-style-link"><p class="nav-item" style="display: inline-block; padding-right: 20px; color: #666;">PATIENT</p></a>
               <a href="doctor-login.php" class="non-style-link"><p class="nav-item" style="display: inline-block; padding-right: 20px; color: #666;">DOCTOR</p></a>
               <a href="admin-login.php" class="non-style-link"><p class="nav-item" style="display: inline-block; padding-right: 20px; color: #666;">ADMIN</p></a>
            </td>
            <td width="10%">
                <a href="register.php" class="non-style-link"><p class="nav-item" style="padding-right: 10px; color: #666;">REGISTER</p></a>
            </td>
        </tr>
    </table>

    <?php
    session_start();

    $_SESSION["user"]="";
    $_SESSION["usertype"]="";
    
    // Set the new timezone
    date_default_timezone_set('Asia/Kolkata');
    $date = date('Y-m-d');

    $_SESSION["date"]=$date;
    

    //import database
    include("connection.php");

    if($_POST){

        $email=$_POST['useremail'];
        $password=$_POST['userpassword'];
        
        $error='<label for="promter" class="form-label"></label>';

        $stmt = $database->prepare("select * from webuser where email=?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        if($result->num_rows==1){
            $utype=$result->fetch_assoc()['usertype'];
            if($utype=='p'){
                $stmt = $database->prepare("select * from patient where pemail=?");
                $stmt->bind_param("s", $email);
                $stmt->execute();
                $checker = $stmt->get_result();
                if ($checker->num_rows==1){
                    $row = $checker->fetch_assoc();
                    if (password_verify($password, $row['ppassword'])) {
                        $_SESSION['user']=$email;
                        $_SESSION['usertype']='p';
                        header('location: patient/index.php'); exit();
                    } else {
                        $error='<label for="promter" class="form-label" style="color:rgb(255, 62, 62);text-align:center;">Wrong credentials: Invalid email or password</label>';
                    }
                }
            }else{
                $error='<label for="promter" class="form-label" style="color:rgb(255, 62, 62);text-align:center;">This login is for Patients only.</label>';
            }
        }else{
            $error='<label for="promter" class="form-label" style="color:rgb(255, 62, 62);text-align:center;">We cant found any acount for this email.</label>';
        }
    }else{
        $error='<label for="promter" class="form-label">&nbsp;</label>';
    }

    ?>

    <center>
        <div style="margin-top: 60px;"></div> <!-- Spacer for full-width navbar -->
    <div class="container">
        <table border="0" style="margin: 0;padding: 0;width: 60%;">
            <tr>
                <td>
                    <p class="header-text">Patient Login</p>
                </td>
            </tr>
        <div class="form-body">
            <tr>
                <td>
                    <p class="sub-text">Login with your Patient details to continue</p>
                </td>
            </tr>
            <tr>
                <form action="" method="POST" >
                <td class="label-td">
                    <label for="useremail" class="form-label">Email: </label>
                </td>
            </tr>
            <tr>
                <td class="label-td">
                    <input type="email" name="useremail" class="input-text" placeholder="Email Address" required>
                </td>
            </tr>
            <tr>
                <td class="label-td">
                    <label for="userpassword" class="form-label">Password: </label>
                </td>
            </tr>

            <tr>
                <td class="label-td">
                    <input type="Password" name="userpassword" class="input-text" placeholder="Password" required>
                </td>
            </tr>

            <tr>
                <td><br>
                <?php echo $error ?>
                </td>
            </tr>

            <tr>
                <td>
                    <input type="submit" value="Login" class="login-btn btn-primary btn">
                </td>
            </tr>
        </div>
            <tr>
                <td>
                    <br>
                    <label for="" class="sub-text" style="font-weight: 280;">Don't have an account&#63; </label>
                    <a href="signup.php" class="hover-link1 non-style-link">Sign Up</a>
                    <br><br><br>
                </td>
            </tr>
        </table>
    </div>
</center>
</body>
</html>
