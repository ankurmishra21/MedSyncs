<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/animations.css">  
    <link rel="stylesheet" href="css/main.css">  
    <link rel="stylesheet" href="css/signup.css">
        
    <title>Admin Sign Up | MedSync</title>
</head>
<body>
    <!-- Navigation Bar -->
    <table border="0" style="width: 100%; padding: 0; margin: 0; border-spacing: 0;">
        <tr style="background-color: #fff; box-shadow: 0 2px 5px rgba(0,0,0,0.05);">
            <td width="50%" style="text-align: left; padding: 10px 0;">
                <a href="index.html" class="non-style-link">
                    <font class="medsync-logo" style="color: var(--primarycolor);">MedSync. </font>
                    <font class="medsync-logo-sub" style="color: #888;">| THE ECHANNELING PROJECT</font>
                </a>
            </td>
            <td width="40%" style="text-align: right;">
               <a href="patient-login.php" class="non-style-link"><p class="nav-item" style="display: inline-block; padding-right: 20px; color: #666;">PATIENT</p></a>
               <a href="doctor-login.php" class="non-style-link"><p class="nav-item" style="display: inline-block; padding-right: 20px; color: #666;">DOCTOR</p></a>
               <a href="admin-login.php" class="non-style-link"><p class="nav-item" style="display: inline-block; padding-right: 20px; color: #666;">ADMIN</p></a>
            </td>
            <td width="10%">
                <a href="register.php" class="non-style-link"><p class="nav-item" style="padding-right: 10px; color: #666;">REGISTER</p></a>
            </td>
        </tr>
    </table>
<?php
session_start();
include("connection.php");

if($_POST){
    $email = $_POST['email'];
    $password = $_POST['password'];
    $cpassword = $_POST['cpassword'];

    if($password == $cpassword){
        $res = $database->query("select * from webuser where email='$email'");
        if($res->num_rows == 1){
            $error = "Account already exists for this email.";
        } else {
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            
            // Insert into admin table
            $stmt = $database->prepare("insert into admin(aemail, apassword) values(?,?)");
            $stmt->bind_param("ss", $email, $hashed_password);
            $stmt->execute();

            // Insert into webuser table
            $stmt = $database->prepare("insert into webuser values(?, 'a')");
            $stmt->bind_param("s", $email);
            $stmt->execute();

            $_SESSION["user"] = $email;
            $_SESSION["usertype"] = "a";
            header("location: admin/index.php"); exit();
        }
    } else {
        $error = "Passwords do not match.";
    }
}
?>

    <center>
        <div style="margin-top: 60px;"></div> <!-- Spacer for full-width navbar -->
    <div class="container">
            <table border="0">
                <tr>
                    <td colspan="2">
                        <p class="header-text">Admin Registration</p>
                        <p class="sub-text">Create a new administrator account</p>
                    </td>
                </tr>
                <form action="" method="POST">
                <tr>
                    <td class="label-td" colspan="2">
                        <input type="email" name="email" class="input-text" placeholder="Email Address" required>
                    </td>
                </tr>
                <tr>
                    <td class="label-td" colspan="2">
                        <input type="password" name="password" class="input-text" placeholder="Password" required>
                    </td>
                </tr>
                <tr>
                    <td class="label-td" colspan="2">
                        <input type="password" name="cpassword" class="input-text" placeholder="Confirm Password" required>
                    </td>
                </tr>
                <tr>
                    <td colspan="2">
                        <label class="form-label" style="color:red;"><?php echo isset($error)?$error:''; ?></label>
                    </td>
                </tr>
                <tr>
                    <td><input type="reset" value="Reset" class="login-btn btn-primary-soft btn"></td>
                    <td><input type="submit" value="Sign Up" class="login-btn btn-primary btn"></td>
                </tr>
                </form>
            </table>
        </div>
    </center>
</body>
</html>
