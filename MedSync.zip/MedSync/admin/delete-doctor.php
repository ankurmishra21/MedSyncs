<?php

    session_start();

    if(isset($_SESSION["user"])){
        if(($_SESSION["user"])=="" or $_SESSION['usertype']!='a'){
            header("location: ../login.php"); exit();
        }

    }else{
        header("location: ../login.php"); exit();
    }
    
    
    if($_GET){
        //import database
        include("../connection.php");
        $id=$_GET["id"];
        $stmt = $database->prepare("select docemail from doctor where docid=?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result001 = $stmt->get_result();
        
        if($result001->num_rows == 1){
            $email=($result001->fetch_assoc())["docemail"];

            $stmt = $database->prepare("delete from webuser where email=?");
            $stmt->bind_param("s", $email);
            $stmt->execute();

            $stmt = $database->prepare("delete from doctor where docemail=?");
            $stmt->bind_param("s", $email);
            $stmt->execute();
        }
        
        header("location: doctors.php"); exit();
    }


?>
