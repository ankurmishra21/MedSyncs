<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/animations.css">  
    <link rel="stylesheet" href="css/main.css">  
    <link rel="stylesheet" href="css/signup.css">
        
    <title>Create Account</title>
    <style>
        .container{
            animation: transitionIn-X 0.5s;
        }
    </style>
</head>
<body>
    <!-- Navigation Bar -->
    <table border="0" style="width: 100%; padding: 0; margin: 0; border-spacing: 0;">
        <tr style="background-color: #fff; box-shadow: 0 2px 5px rgba(0,0,0,0.05);">
            <td width="50%" style="text-align: left; padding: 10px 0;">
                <a href="index.html" class="non-style-link">
                    <font class="medsync-logo" style="color: var(--primarycolor);">MedSync. </font>
                    <font class="medsync-logo-sub" style="color: #888;">| THE ECHANNELING PROJECT</font>
                </a>
            </td>
            <td width="40%" style="text-align: right;">
               <a href="patient-login.php" class="non-style-link"><p class="nav-item" style="display: inline-block; padding-right: 20px; color: #666;">PATIENT</p></a>
               <a href="doctor-login.php" class="non-style-link"><p class="nav-item" style="display: inline-block; padding-right: 20px; color: #666;">DOCTOR</p></a>
               <a href="admin-login.php" class="non-style-link"><p class="nav-item" style="display: inline-block; padding-right: 20px; color: #666;">ADMIN</p></a>
            </td>
            <td width="10%">
                <a href="register.php" class="non-style-link"><p class="nav-item" style="padding-right: 10px; color: #666;">REGISTER</p></a>
            </td>
        </tr>
    </table>
<?php

//learn from w3schools.com
//Unset all the server side variables

session_start();

$_SESSION["user"]="";
$_SESSION["usertype"]="";

// Set the new timezone
date_default_timezone_set('Asia/Kolkata');
$date = date('Y-m-d');

$_SESSION["date"]=$date;


//import database
include("connection.php");





if($_POST){

    $result= $database->query("select * from webuser");

    $fname=$_SESSION['personal']['fname'];
    $lname=$_SESSION['personal']['lname'];
    $name=$fname." ".$lname;
    $address=$_SESSION['personal']['address'];
    $nic=$_SESSION['personal']['nic'];
    $dob=$_SESSION['personal']['dob'];
    $email=$_POST['newemail'];
    $tele=$_POST['tele'];
    $newpassword=$_POST['newpassword'];
    $cpassword=$_POST['cpassword'];
    
    if ($newpassword==$cpassword){
        $sqlmain= "select * from webuser where email=?;";
        $stmt = $database->prepare($sqlmain);
        $stmt->bind_param("s",$email);
        $stmt->execute();
        $result = $stmt->get_result();
        if($result->num_rows==1){
            $error='<label for="promter" class="form-label" style="color:rgb(255, 62, 62);text-align:center;">Already have an account for this Email address.</label>';
        }else{
            $hashed_password = password_hash($newpassword, PASSWORD_DEFAULT);
            $stmt = $database->prepare("insert into patient(pemail,pname,ppassword, paddress, pnic,pdob,ptel) values(?,?,?,?,?,?,?)");
            $stmt->bind_param("sssssss", $email, $name, $hashed_password, $address, $nic, $dob, $tele);
            $stmt->execute();

            $stmt = $database->prepare("insert into webuser values(?, 'p')");
            $stmt->bind_param("s", $email);
            $stmt->execute();

            $_SESSION["user"]=$email;
            $_SESSION["usertype"]="p";
            $_SESSION["username"]=$fname;

            header('Location: patient/index.php'); exit();
            $error='<label for="promter" class="form-label" style="color:rgb(255, 62, 62);text-align:center;"></label>';
        }
        
    }else{
        $error='<label for="promter" class="form-label" style="color:rgb(255, 62, 62);text-align:center;">Password Conformation Error! Reconform Password</label>';
    }



    
}else{
    //header('location: signup.php'); exit();
    $error='<label for="promter" class="form-label"></label>';
}

?>
    <center>
        <div style="margin-top: 60px;"></div> <!-- Spacer for full-width navbar -->
    <div class="container">
        <table border="0" style="width: 69%;">
            <tr>
                <td colspan="2">
                    <p class="header-text">Let's Get Started</p>
                    <p class="sub-text">It's Okey, Now Create User Account.</p>
                </td>
            </tr>
            <tr>
                <form action="" method="POST" >
                <td class="label-td" colspan="2">
                    <label for="newemail" class="form-label">Email: </label>
                </td>
            </tr>
            <tr>
                <td class="label-td" colspan="2">
                    <input type="email" name="newemail" class="input-text" placeholder="Email Address" required>
                </td>
                
            </tr>
            <tr>
                <td class="label-td" colspan="2">
                    <label for="tele" class="form-label">Mobile Number: </label>
                </td>
            </tr>
            <tr>
                <td class="label-td" colspan="2">
                    <input type="tel" name="tele" class="input-text"  placeholder="ex: 9876543210" pattern="[0-9]{10}" >
                </td>
            </tr>
            <tr>
                <td class="label-td" colspan="2">
                    <label for="newpassword" class="form-label">Create New Password: </label>
                </td>
            </tr>
            <tr>
                <td class="label-td" colspan="2">
                    <input type="password" name="newpassword" class="input-text" placeholder="New Password" required>
                </td>
            </tr>
            <tr>
                <td class="label-td" colspan="2">
                    <label for="cpassword" class="form-label">Conform Password: </label>
                </td>
            </tr>
            <tr>
                <td class="label-td" colspan="2">
                    <input type="password" name="cpassword" class="input-text" placeholder="Conform Password" required>
                </td>
            </tr>
     
            <tr>
                
                <td colspan="2">
                    <?php echo $error ?>

                </td>
            </tr>
            
            <tr>
                <td>
                    <input type="reset" value="Reset" class="login-btn btn-primary-soft btn" >
                </td>
                <td>
                    <input type="submit" value="Sign Up" class="login-btn btn-primary btn">
                </td>

            </tr>
            <tr>
                <td colspan="2">
                    <br>
                    <label for="" class="sub-text" style="font-weight: 280;">Already have an account&#63; </label>
                    <a href="login.php" class="hover-link1 non-style-link">Login</a>
                    <br><br><br>
                </td>
            </tr>

                    </form>
            </tr>
        </table>

    </div>
</center>
</body>
</html>
