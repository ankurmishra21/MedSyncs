
    <?php
    
    

    //import database
    include("../connection.php");



    if($_POST){
        $name=$_POST['name'];
        $nic=$_POST['nic'];
        $oldemail=$_POST["oldemail"];
        $spec=$_POST['spec'];
        $email=$_POST['email'];
        $tele=$_POST['Tele'];
        $password=$_POST['password'];
        $cpassword=$_POST['cpassword'];
        $id=$_POST['id00'];
        
        if ($password==$cpassword){
            $error='3';
            $stmt = $database->prepare("select doctor.docid from doctor inner join webuser on doctor.docemail=webuser.email where webuser.email=?");
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $result = $stmt->get_result();
            if($result->num_rows==1){
                $id2=$result->fetch_assoc()["docid"];
            }else{
                $id2=$id;
            }
            
            if($id2!=$id){
                $error='1';
            }else{
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                $stmt = $database->prepare("update doctor set docemail=?, docname=?, docpassword=?, docnic=?, doctel=?, specialties=? where docid=?");
                $stmt->bind_param("sssssii", $email, $name, $hashed_password, $nic, $tele, $spec, $id);
                $stmt->execute();
                
                $stmt = $database->prepare("update webuser set email=? where email=?");
                $stmt->bind_param("ss", $email, $oldemail);
                $stmt->execute();

                $error= '4';
            }
        }else{
            $error='2';
        }
    }else{
        $error='3';
    }

    header("location: doctors.php?action=edit&error=".$error."&id=".$id); exit();
    ?>
    
   

</body>
</html>
