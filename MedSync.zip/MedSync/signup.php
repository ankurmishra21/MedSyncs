<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/animations.css">  
    <link rel="stylesheet" href="css/main.css">  
    <link rel="stylesheet" href="css/signup.css">
        
    <title>Sign Up</title>
    
</head>
<body>
    <!-- Navigation Bar -->
    <table border="0" style="width: 100%; padding: 0; margin: 0; border-spacing: 0;">
        <tr style="background-color: #fff; box-shadow: 0 2px 5px rgba(0,0,0,0.05);">
            <td width="50%" style="text-align: left; padding: 10px 0;">
                <a href="index.html" class="non-style-link">
                    <font class="medsync-logo" style="color: var(--primarycolor);">MedSync. </font>
                    <font class="medsync-logo-sub" style="color: #888;">| THE ECHANNELING PROJECT</font>
                </a>
            </td>
            <td width="40%" style="text-align: right;">
               <a href="patient-login.php" class="non-style-link"><p class="nav-item" style="display: inline-block; padding-right: 20px; color: #666;">PATIENT</p></a>
               <a href="doctor-login.php" class="non-style-link"><p class="nav-item" style="display: inline-block; padding-right: 20px; color: #666;">DOCTOR</p></a>
               <a href="admin-login.php" class="non-style-link"><p class="nav-item" style="display: inline-block; padding-right: 20px; color: #666;">ADMIN</p></a>
            </td>
            <td width="10%">
                <a href="register.php" class="non-style-link"><p class="nav-item" style="padding-right: 10px; color: #666;">REGISTER</p></a>
            </td>
        </tr>
    </table>
<?php

//learn from w3schools.com
//Unset all the server side variables

session_start();

$_SESSION["user"]="";
$_SESSION["usertype"]="";

// Set the new timezone
date_default_timezone_set('Asia/Kolkata');
$date = date('Y-m-d');

$_SESSION["date"]=$date;



if($_POST){

    

    $_SESSION["personal"]=array(
        'fname'=>$_POST['fname'],
        'lname'=>$_POST['lname'],
        'address'=>$_POST['address'],
        'nic'=>$_POST['nic'],
        'dob'=>$_POST['dob']
    );


    print_r($_SESSION["personal"]);
    header("location: create-account.php"); exit();




}

?>

    <center>
        <div style="margin-top: 60px;"></div> <!-- Spacer for full-width navbar -->
    <div class="container">
        <table border="0">
            <tr>
                <td colspan="2">
                    <p class="header-text">Let's Get Started</p>
                    <p class="sub-text">Add Your Personal Details to Continue</p>
                </td>
            </tr>
            <tr>
                <form action="" method="POST" >
                <td class="label-td" colspan="2">
                    <label for="name" class="form-label">Name: </label>
                </td>
            </tr>
            <tr>
                <td class="label-td">
                    <input type="text" name="fname" class="input-text" placeholder="First Name" required>
                </td>
                <td class="label-td">
                    <input type="text" name="lname" class="input-text" placeholder="Last Name" required>
                </td>
            </tr>
            <tr>
                <td class="label-td" colspan="2">
                    <label for="address" class="form-label">Address: </label>
                </td>
            </tr>
            <tr>
                <td class="label-td" colspan="2">
                    <input type="text" name="address" class="input-text" placeholder="Address" required>
                </td>
            </tr>
            <tr>
                <td class="label-td" colspan="2">
                    <label for="nic" class="form-label">NIC: </label>
                </td>
            </tr>
            <tr>
                <td class="label-td" colspan="2">
                    <input type="text" name="nic" class="input-text" placeholder="NIC Number" required>
                </td>
            </tr>
            <tr>
                <td class="label-td" colspan="2">
                    <label for="dob" class="form-label">Date of Birth: </label>
                </td>
            </tr>
            <tr>
                <td class="label-td" colspan="2">
                    <input type="date" name="dob" class="input-text" required>
                </td>
            </tr>
            <tr>
                <td class="label-td" colspan="2">
                </td>
            </tr>

            <tr>
                <td>
                    <input type="reset" value="Reset" class="login-btn btn-primary-soft btn" >
                </td>
                <td>
                    <input type="submit" value="Next" class="login-btn btn-primary btn">
                </td>

            </tr>
            <tr>
                <td colspan="2">
                    <br>
                    <label for="" class="sub-text" style="font-weight: 280;">Already have an account&#63; </label>
                    <a href="login.php" class="hover-link1 non-style-link">Login</a>
                    <br><br><br>
                </td>
            </tr>

                    </form>
            </tr>
        </table>

    </div>
</center>
</body>
</html>
