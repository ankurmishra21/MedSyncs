<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/animations.css">  
    <link rel="stylesheet" href="css/main.css">  
    <link rel="stylesheet" href="css/index.css">
    <title>Register | MedSync</title>
    <style>
        .container{
            animation: transitionIn-Y-bottom 0.5s;
        }
        .role-card {
            background-color: rgba(255, 255, 255, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.2);
            border-radius: 10px;
            padding: 30px;
            margin: 20px;
            width: 200px;
            display: inline-block;
            transition: 0.3s;
            cursor: pointer;
            text-decoration: none;
            color: white;
        }
        .role-card:hover {
            background-color: rgba(255, 255, 255, 0.2);
            transform: translateY(-5px);
        }
        .role-icon {
            font-size: 50px;
            margin-bottom: 15px;
        }
        .role-title {
            font-size: 20px;
            font-weight: 600;
        }
    </style>
</head>
<body class="full-height">
    <!-- Navigation Bar -->
    <table border="0" style="width: 100%; padding: 0; margin: 0; border-spacing: 0;">
        <tr>
            <td width="50%" style="text-align: left; padding: 10px 0;">
                <a href="index.html" class="non-style-link">
                    <font class="medsync-logo" style="color: white;">MedSync. </font>
                    <font class="medsync-logo-sub" style="color: rgba(255,255,255,0.7);">| THE ECHANNELING PROJECT</font>
                </a>
            </td>
            <td width="40%" style="text-align: right;">
               <a href="patient-login.php" class="non-style-link"><p class="nav-item" style="display: inline-block; padding-right: 20px; color: rgba(255,255,255,0.671);">PATIENT</p></a>
               <a href="doctor-login.php" class="non-style-link"><p class="nav-item" style="display: inline-block; padding-right: 20px; color: rgba(255,255,255,0.671);">DOCTOR</p></a>
               <a href="admin-login.php" class="non-style-link"><p class="nav-item" style="display: inline-block; padding-right: 20px; color: rgba(255,255,255,0.671);">ADMIN</p></a>
            </td>
            <td width="10%">
                <a href="register.php" class="non-style-link"><p class="nav-item" style="padding-right: 10px; color: white; font-weight: bold;">REGISTER</p></a>
            </td>
        </tr>
    </table>

    <center>

        <div class="container" style="margin-top: 50px;">
            <p class="heading-text" style="margin-top: 0;">Who are you?</p>
            <p class="sub-text2">Select your role to start registration</p>
            
            <div style="margin-top: 30px;">
                <a href="signup.php" class="role-card">
                    <div class="role-icon">👤</div>
                    <div class="role-title">Patient</div>
                </a>
                
                <a href="doctor-signup.php" class="role-card">
                    <div class="role-icon">🩺</div>
                    <div class="role-title">Doctor</div>
                </a>
                
                <a href="admin-signup.php" class="role-card">
                    <div class="role-icon">⚙️</div>
                    <div class="role-title">Admin</div>
                </a>
            </div>
            
            <p class="sub-text2" style="margin-top: 40px;">
                Already have an account? <a href="login.php" style="color: white; font-weight: bold;">Login</a>
            </p>
        </div>
    </center>
</body>
</html>
