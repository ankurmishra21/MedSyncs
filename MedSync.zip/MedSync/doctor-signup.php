<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/animations.css">  
    <link rel="stylesheet" href="css/main.css">  
    <link rel="stylesheet" href="css/signup.css">
        
    <title>Doctor Sign Up | MedSync</title>
</head>
<body>
    <!-- Navigation Bar -->
    <table border="0" style="width: 100%; padding: 0; margin: 0; border-spacing: 0;">
        <tr style="background-color: #fff; box-shadow: 0 2px 5px rgba(0,0,0,0.05);">
            <td width="50%" style="text-align: left; padding: 10px 0;">
                <a href="index.html" class="non-style-link">
                    <font class="medsync-logo" style="color: var(--primarycolor);">MedSync. </font>
                    <font class="medsync-logo-sub" style="color: #888;">| THE ECHANNELING PROJECT</font>
                </a>
            </td>
            <td width="40%" style="text-align: right;">
               <a href="patient-login.php" class="non-style-link"><p class="nav-item" style="display: inline-block; padding-right: 20px; color: #666;">PATIENT</p></a>
               <a href="doctor-login.php" class="non-style-link"><p class="nav-item" style="display: inline-block; padding-right: 20px; color: #666;">DOCTOR</p></a>
               <a href="admin-login.php" class="non-style-link"><p class="nav-item" style="display: inline-block; padding-right: 20px; color: #666;">ADMIN</p></a>
            </td>
            <td width="10%">
                <a href="register.php" class="non-style-link"><p class="nav-item" style="padding-right: 10px; color: #666;">REGISTER</p></a>
            </td>
        </tr>
    </table>
<?php
session_start();
include("connection.php");

if($_POST){
    // Collect data
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $name = $fname." ".$lname;
    $email = $_POST['email'];
    $tele = $_POST['tele'];
    $nic = $_POST['nic'];
    $spec = $_POST['spec'];
    $password = $_POST['password'];
    $cpassword = $_POST['cpassword'];

    if($password == $cpassword){
        $res = $database->query("select * from webuser where email='$email'");
        if($res->num_rows == 1){
            $error = "Account already exists for this email.";
        } else {
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            
            // Insert into doctor table
            $stmt = $database->prepare("insert into doctor(docemail, docname, docpassword, docnic, doctel, specialties) values(?,?,?,?,?,?)");
            $stmt->bind_param("sssssi", $email, $name, $hashed_password, $nic, $tele, $spec);
            $stmt->execute();

            // Insert into webuser table
            $stmt = $database->prepare("insert into webuser values(?, 'd')");
            $stmt->bind_param("s", $email);
            $stmt->execute();

            $_SESSION["user"] = $email;
            $_SESSION["usertype"] = "d";
            header("location: doctor/index.php"); exit();
        }
    } else {
        $error = "Passwords do not match.";
    }
}
?>

    <center>
        <div style="margin-top: 60px;"></div> <!-- Spacer for full-width navbar -->
    <div class="container">
            <table border="0">
                <tr>
                    <td colspan="2">
                        <p class="header-text">Doctor Registration</p>
                        <p class="sub-text">Enter your professional details to continue</p>
                    </td>
                </tr>
                <form action="" method="POST">
                <tr>
                    <td class="label-td">
                        <input type="text" name="fname" class="input-text" placeholder="First Name" required>
                    </td>
                    <td class="label-td">
                        <input type="text" name="lname" class="input-text" placeholder="Last Name" required>
                    </td>
                </tr>
                <tr>
                    <td class="label-td" colspan="2">
                        <input type="email" name="email" class="input-text" placeholder="Email Address" required>
                    </td>
                </tr>
                <tr>
                    <td class="label-td" colspan="2">
                        <input type="tel" name="tele" class="input-text" placeholder="Mobile Number" pattern="[0-9]{10}" required>
                    </td>
                </tr>
                <tr>
                    <td class="label-td" colspan="2">
                        <input type="text" name="nic" class="input-text" placeholder="NIC Number" required>
                    </td>
                </tr>
                <tr>
                    <td class="label-td" colspan="2">
                        <label for="spec" class="form-label">Specialty: </label>
                        <select name="spec" class="input-text" style="width: 100%;">
                            <?php
                            $list = $database->query("select * from specialties order by sname asc;");
                            while($row = $list->fetch_assoc()){
                                echo "<option value='".$row['id']."'>".$row['sname']."</option>";
                            }
                            ?>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td class="label-td" colspan="2">
                        <input type="password" name="password" class="input-text" placeholder="Password" required>
                    </td>
                </tr>
                <tr>
                    <td class="label-td" colspan="2">
                        <input type="password" name="cpassword" class="input-text" placeholder="Confirm Password" required>
                    </td>
                </tr>
                <tr>
                    <td colspan="2">
                        <label class="form-label" style="color:red;"><?php echo isset($error)?$error:''; ?></label>
                    </td>
                </tr>
                <tr>
                    <td><input type="reset" value="Reset" class="login-btn btn-primary-soft btn"></td>
                    <td><input type="submit" value="Sign Up" class="login-btn btn-primary btn"></td>
                </tr>
                </form>
            </table>
        </div>
    </center>
</body>
</html>
